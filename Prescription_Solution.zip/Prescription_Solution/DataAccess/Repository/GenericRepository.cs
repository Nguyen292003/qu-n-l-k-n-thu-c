﻿using BusinessObject;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public abstract class GenericRepository<TEntity> where TEntity : class
    {
        protected readonly PrescriptionContext _context;
        protected DbSet<TEntity> _entities;
        public GenericRepository(PrescriptionContext context)
        {
            _context = context;
            _entities = _context.Set<TEntity>();
        }
        public virtual async Task<TEntity> Add(TEntity entity)
        {
            var e = _entities.Add(entity).Entity;
            await _context.SaveChangesAsync();
            return e;
        }

        public virtual async Task<bool> Delete(TEntity entity)
        {
            try
            {
                _entities.Remove(entity);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        public async Task<TEntity> GetFirst(Expression<Func<TEntity, bool>>? expression = null, params string[] includeProperties)
        {
            IQueryable<TEntity>? query = _entities;
            query = expression == null ? query : query.Where(expression);
            if (includeProperties != null)
            {
                foreach (var property in includeProperties)
                {
                    query = query.Include(property);
                }
            }
            return await query.FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<TEntity>> GetMany(Expression<Func<TEntity, bool>>? expression = null, params string[] includeProperties)
        {
            IQueryable<TEntity>? query = _entities;
            query = expression == null ? query : query.Where(expression);
            if (includeProperties != null)
            {
                foreach (var property in includeProperties)
                {
                    query = query.Include(property);
                }
            }
            return await query.ToListAsync();
        }

        public virtual async Task<bool> Update(TEntity entity)
        {
            try
            {
                _entities.Update(entity);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        public virtual async Task<bool> UpdateRange(IEnumerable<TEntity> entities)
        {
            try
            {
                _entities.UpdateRange(entities);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }
        public virtual async Task<bool> AddRange(IEnumerable<TEntity> entities)
        {
            try
            {
                await _entities.AddRangeAsync(entities);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }
        public virtual async Task<bool> DeleteRange(IEnumerable<TEntity> entities)
        {
            try
            {
                _entities.RemoveRange(entities);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
