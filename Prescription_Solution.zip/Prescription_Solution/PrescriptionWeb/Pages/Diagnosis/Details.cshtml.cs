﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;

namespace PrescriptionWeb.Pages.Diagnosis
{
    public class DetailsModel : PageModel
    {
        private readonly DiagnosisRepository _repo;

        public DetailsModel(DiagnosisRepository repo)
        {
            _repo = repo;
        }

      public BusinessObject.Models.Diagnosis Diagnosis { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var diagnosis = await _repo.GetFirst(m => m.DiagnosisId == id);
            if (diagnosis == null)
            {
                return NotFound();
            }
            else 
            {
                Diagnosis = diagnosis;
            }
            return Page();
        }
    }
}
