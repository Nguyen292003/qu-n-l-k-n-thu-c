﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;

namespace PrescriptionWeb.Pages.Diagnosis
{
    public class DeleteModel : PageModel
    {
        private readonly DiagnosisRepository _repo;

        public DeleteModel(DiagnosisRepository repo)
        {
            _repo = repo;
        }

        [BindProperty]
      public BusinessObject.Models.Diagnosis Diagnosis { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var diagnosis = await _repo.GetFirst(m => m.DiagnosisId == id);

            if (diagnosis == null)
            {
                return NotFound();
            }
            else 
            {
                Diagnosis = diagnosis;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var diagnosis = await _repo.GetFirst(d => d.DiagnosisId == id);

            if (diagnosis != null)
            {
                Diagnosis = diagnosis;
                await _repo.Delete(Diagnosis);
            }

            return RedirectToPage("./Index");
        }
    }
}
