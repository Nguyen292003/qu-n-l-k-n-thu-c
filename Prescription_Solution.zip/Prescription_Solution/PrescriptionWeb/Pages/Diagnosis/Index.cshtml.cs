﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;

namespace PrescriptionWeb.Pages.Diagnosis
{
    public class IndexModel : PageModel
    {
        private readonly DiagnosisRepository _repo;

        public IndexModel(DiagnosisRepository repo)
        {
            _repo = repo;
        }

        public IList<BusinessObject.Models.Diagnosis> Diagnoses { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Diagnoses = (await _repo.GetMany()).ToList();
        }
    }
}
