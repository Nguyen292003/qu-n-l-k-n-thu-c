﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;

namespace PrescriptionWeb.Pages.Prescription
{
    public class DeleteModel : PageModel
    {
        private readonly PrescriptionRepository _repo;
        public readonly MedicationRepository _medicationRepo;
        public readonly DiagnosisRepository _diagnosisRepo;
        private readonly PrescriptionDiagnosisRepository _prescriptionDiagnosisRepo;
        public readonly PrescriptionMedicationRepository _prescriptionMedicationRepo;

        public DeleteModel(PrescriptionRepository repo, MedicationRepository medicationRepo, DiagnosisRepository diagnosisRepo, PrescriptionDiagnosisRepository prescriptionDiagnosisRepo, PrescriptionMedicationRepository prescriptionMedicationRepo)
        {
            _repo = repo;
            _medicationRepo = medicationRepo;
            _diagnosisRepo = diagnosisRepo;
            _prescriptionDiagnosisRepo = prescriptionDiagnosisRepo;
            _prescriptionMedicationRepo = prescriptionMedicationRepo;
        }
        public List<BusinessObject.Models.PrescriptionMedication> PrescriptionMedications { get; set; }
        public List<BusinessObject.Models.PrescriptionDiagnosis> PrescriptionDiagnoses { get; set; }
        [BindProperty]
      public BusinessObject.Models.Prescription Prescription { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var prescription = await _repo.GetFirst(m => m.PrescriptionId == id);

            if (prescription == null)
            {
                return NotFound();
            }
            else 
            {
                Prescription = prescription;
            }
            PrescriptionDiagnoses = (await _prescriptionDiagnosisRepo.GetMany(pd => pd.PrescriptionId == prescription.PrescriptionId)).ToList();
            PrescriptionMedications = (await _prescriptionMedicationRepo.GetMany(pm => pm.PrescriptionId == prescription.PrescriptionId)).ToList();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var prescription = await _repo.GetFirst(m => m.PrescriptionId == id);

            if (prescription != null)
            {
                Prescription = prescription;
                await _repo.Delete(Prescription);
            }

            return RedirectToPage("./Index");
        }
    }
}
