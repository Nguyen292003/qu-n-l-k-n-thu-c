﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace PrescriptionWeb.Pages.Prescription
{
    public class CreateModel : PageModel
    {
        private readonly PrescriptionRepository _repo;
        private readonly MedicationRepository _medicationRepo;
        private readonly DiagnosisRepository _diagnosisRepo;
        private readonly PrescriptionDiagnosisRepository _prescriptionDiagnosisRepo;
        private readonly PrescriptionMedicationRepository _prescriptionMedicationRepo;

        public CreateModel(PrescriptionRepository repo, MedicationRepository medicationRepo, DiagnosisRepository diagnosisRepo, PrescriptionDiagnosisRepository prescriptionDiagnosisRepo, PrescriptionMedicationRepository prescriptionMedicationRepo)
        {
            _repo = repo;
            _medicationRepo = medicationRepo;
            _diagnosisRepo = diagnosisRepo;
            _prescriptionDiagnosisRepo = prescriptionDiagnosisRepo;
            _prescriptionMedicationRepo = prescriptionMedicationRepo;
        }

        public void OnGet()
        {
            Diagnoses = (_diagnosisRepo.GetMany().Result).ToList();
            Medications = (_medicationRepo.GetMany().Result).ToList();
        }
        public List<BusinessObject.Models.PrescriptionMedication> PrescriptionMedications { get; set; }
        public List<BusinessObject.Models.PrescriptionDiagnosis> PrescriptionDiagnoses { get; set; }
        public List<BusinessObject.Models.Medication> Medications { get; set; }

        public List<BusinessObject.Models.Diagnosis> Diagnoses { get; set; }
        [BindProperty]
        public BusinessObject.Models.Prescription Prescription { get; set; } = default!;

        public string ErrorMessage { get; set; }


        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync(string[] medications, string[] diagnoses)
        {
            OnGet();
            if (!ModelState.IsValid)
            {
                return Page();
            }
            if (diagnoses.IsNullOrEmpty())
            {
                TempData["ErrorMessage"] = "Cần chọn ít nhất 1 chẩn đoán";
                return Page();
            }
            if (medications.IsNullOrEmpty())
            {
                TempData["ErrorMessage"] = "Cần chọn ít nhất 1 đơn thuốc";
                return Page();
            }
            if (Prescription.Phone.Length < 10 || Prescription.Phone.Length > 12)
            {
                TempData["ErrorMessage"] = "Độ dài số điện thoại phải nằm trong khoảng 10-12!";
                return Page();
            }
            var prescription = await _repo.Add(Prescription);
            if (prescription == null)
            {
                TempData["ErrorMessage"] = "Thêm thất bại!";
                return Page();
            }
            foreach (var diagnosis in diagnoses)
            {
                BusinessObject.Models.Diagnosis diagnosisObj = await _diagnosisRepo.GetFirst(d => d.DiagnosisId == diagnosis);
                if (diagnosisObj != null)
                {
                    await _prescriptionDiagnosisRepo.Add(new PrescriptionDiagnosis()
                    {
                        DiagnosisId = diagnosisObj.DiagnosisId,
                        PrescriptionId = Prescription.PrescriptionId
                    });
                }
            }
            List<BusinessObject.Models.Medication> listMed = new List<BusinessObject.Models.Medication>();
            foreach (var medication in medications)
            {
                BusinessObject.Models.Medication medicationObj = await _medicationRepo.GetFirst(m => m.MedicationId == medication);
                if (medicationObj != null)
                {
                    listMed.Add(medicationObj);
                    //await _prescriptionMedicationRepo.Add(new PrescriptionMedication()
                    //{
                    //    MedicationId = medicationObj.MedicationId,
                    //    PrescriptionId = Prescription.PrescriptionId
                    //});
                }
            }
            HttpContext.Session.SetString("Medications", JsonConvert.SerializeObject(listMed));
            
            return Redirect($"/Prescription/MedicationGuide/{prescription.PrescriptionId}");
        }
    }
}
