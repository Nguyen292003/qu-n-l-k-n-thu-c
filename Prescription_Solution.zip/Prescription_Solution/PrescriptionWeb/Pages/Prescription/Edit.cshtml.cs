﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace PrescriptionWeb.Pages.Prescription
{
    public class EditModel : PageModel
    {
        private readonly PrescriptionRepository _repo;
        private readonly MedicationRepository _medicationRepo;
        private readonly DiagnosisRepository _diagnosisRepo;
        private readonly PrescriptionDiagnosisRepository _prescriptionDiagnosisRepo;
        private readonly PrescriptionMedicationRepository _prescriptionMedicationRepo;
        public EditModel(PrescriptionRepository repo, MedicationRepository medicationRepo, DiagnosisRepository diagnosisRepo, PrescriptionDiagnosisRepository prescriptionDiagnosisRepo, PrescriptionMedicationRepository prescriptionMedicationRepo)
        {
            _repo = repo;
            _medicationRepo = medicationRepo;
            _diagnosisRepo = diagnosisRepo;
            _prescriptionDiagnosisRepo = prescriptionDiagnosisRepo;
            _prescriptionMedicationRepo = prescriptionMedicationRepo;
        }
        public List<BusinessObject.Models.PrescriptionMedication> PrescriptionMedications { get; set; }
        public List<BusinessObject.Models.PrescriptionDiagnosis> PrescriptionDiagnoses { get; set; }
        public List<BusinessObject.Models.Medication> Medications { get; set; }

        public List<BusinessObject.Models.Diagnosis> Diagnoses { get; set; }
        [BindProperty]
        public BusinessObject.Models.Prescription Prescription { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            Diagnoses = (await _diagnosisRepo.GetMany()).ToList();
            Medications = (await _medicationRepo.GetMany()).ToList();
            var prescription = await _repo.GetFirst(m => m.PrescriptionId == id);
            if (prescription == null)
            {
                return NotFound();
            }
            PrescriptionDiagnoses = (await _prescriptionDiagnosisRepo.GetMany(pd => pd.PrescriptionId == prescription.PrescriptionId)).ToList();
            PrescriptionMedications = (await _prescriptionMedicationRepo.GetMany(pm => pm.PrescriptionId == prescription.PrescriptionId)).ToList();
            Prescription = prescription;
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync(string[] medications, string[] diagnoses)
        {
            await OnGetAsync(Prescription.PrescriptionId);
            if (!ModelState.IsValid)
            {
                return Page();
            }
            if (diagnoses.IsNullOrEmpty())
            {
                TempData["ErrorMessage"] = "Cần chọn ít nhất 1 chẩn đoán";
                return Page();
            }
            if (medications.IsNullOrEmpty())
            {
                TempData["ErrorMessage"] = "Cần chọn ít nhất 1 đơn thuốc";
                return Page();
            }
            if (Prescription.Phone.Length < 10 || Prescription.Phone.Length > 12)
            {
                TempData["ErrorMessage"] = "Độ dài số điện thoại phải nằm trong khoảng 10-12!";
                return Page();
            }
            var precription = await _repo.GetFirst(p => p.PrescriptionId == Prescription.PrescriptionId);
            if (precription == null)
            {
                TempData["ErrorMessage"] = "Đơn thuốc không tồn tại để chỉnh sửa!";
                return Page();
            }
            bool res = await _repo.Update(Prescription);
            if (res)
            {
                if (!PrescriptionDiagnoses.IsNullOrEmpty())
                {
                    foreach (var prescriptionDiagnosis in PrescriptionDiagnoses)
                    {
                        await _prescriptionDiagnosisRepo.Delete(prescriptionDiagnosis);
                    }
                }
                if (!PrescriptionMedications.IsNullOrEmpty())
                {
                    foreach (var prescriptionMedication in PrescriptionMedications)
                    {
                        await _prescriptionMedicationRepo.Delete(prescriptionMedication);
                    }
                }
                foreach (var diagnosis in diagnoses)
                {
                    BusinessObject.Models.Diagnosis diagnosisObj = await _diagnosisRepo.GetFirst(d => d.DiagnosisId == diagnosis);
                    if (diagnosisObj != null)
                    {
                        await _prescriptionDiagnosisRepo.Add(new PrescriptionDiagnosis()
                        {
                            DiagnosisId = diagnosisObj.DiagnosisId,
                            PrescriptionId = Prescription.PrescriptionId
                        });
                    }
                }
                List<BusinessObject.Models.Medication> listMed = new List<BusinessObject.Models.Medication>();
                foreach (var medication in medications)
                {
                    BusinessObject.Models.Medication medicationObj = await _medicationRepo.GetFirst(m => m.MedicationId == medication);
                    if (medicationObj != null)
                    {
                        listMed.Add(medicationObj);
                        //await _prescriptionMedicationRepo.Add(new PrescriptionMedication()
                        //{
                        //    MedicationId = medicationObj.MedicationId,
                        //    PrescriptionId = Prescription.PrescriptionId
                        //});
                    }
                }
                HttpContext.Session.SetString("Medications", JsonConvert.SerializeObject(listMed));

                return Redirect($"/Prescription/MedicationGuide/{Prescription.PrescriptionId}");
            }
            return Page();
        }
    }
}
