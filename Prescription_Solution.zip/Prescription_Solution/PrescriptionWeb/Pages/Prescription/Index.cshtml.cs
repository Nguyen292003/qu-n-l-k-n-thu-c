﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;

namespace PrescriptionWeb.Pages.Prescription
{
    public class IndexModel : PageModel
    {
        private readonly PrescriptionRepository _repo;

        public IndexModel(PrescriptionRepository repo)
        {
            _repo = repo;
        }

        public IList<BusinessObject.Models.Prescription> Prescription { get; set; } = default!;

        public async Task OnGetAsync()
        {
            Prescription = (await _repo.GetMany()).ToList();
        }
    }
}
