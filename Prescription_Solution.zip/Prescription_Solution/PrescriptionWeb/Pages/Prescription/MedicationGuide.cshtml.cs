﻿using BusinessObject.Models;
using DataAccess.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Routing;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace PrescriptionWeb.Pages.Prescription
{
    public class MedicationGuideModel : PageModel
    {
        private readonly PrescriptionRepository _repo;
        private readonly PrescriptionMedicationRepository _prescriptionMedicationRepo;

        public MedicationGuideModel(PrescriptionRepository repo, PrescriptionMedicationRepository prescriptionMedicationRepo)
        {
            _repo = repo;
            _prescriptionMedicationRepo = prescriptionMedicationRepo;
        }

        public List<BusinessObject.Models.Medication> ListMed { get; set; }

        public BusinessObject.Models.Prescription Prescription { get; set; } = default!;
        public async Task<IActionResult> OnGet(int prescriptionId)
        {
            var prescription = await _repo.GetFirst(p => p.PrescriptionId == prescriptionId);
            if (prescription == null)
            {
                return NotFound();
            }
            Prescription = prescription;
            string medicationsJson = HttpContext.Session.GetString("Medications");
            if (!medicationsJson.IsNullOrEmpty())
            {
                ListMed = JsonConvert.DeserializeObject<List<BusinessObject.Models.Medication>>(medicationsJson);
            }
            return Page();
        }

        public async Task<IActionResult> OnPost(int prescriptionId, string medicationId, string unit, string route, string amount, string divided, string session, string at)
        {
            await OnGet(prescriptionId);
            string guide = $"{route} {amount} {unit}/{divided} lần {session} {at}";
            foreach (var medication in ListMed.ToList())
            {
                if (medication.MedicationId == medicationId)
                {
                    await _prescriptionMedicationRepo.Add(new PrescriptionMedication()
                    {
                        MedicationId = medication.MedicationId,
                        PrescriptionId = Prescription.PrescriptionId,
                        Instructions = guide
                    });
                    ListMed.Remove(medication);
                }
            }
            HttpContext.Session.SetString("Medications", JsonConvert.SerializeObject(ListMed));
            if (ListMed.IsNullOrEmpty())
            {
                HttpContext.Session.Clear();
                return RedirectToPage("/Prescription/Index");
            }
            return Page();
        }
    }
}
