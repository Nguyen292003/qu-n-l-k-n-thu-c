﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;

namespace PrescriptionWeb.Pages.Medication
{
    public class IndexModel : PageModel
    {
        private readonly MedicationRepository _repo;

        public IndexModel(MedicationRepository repo)
        {
            _repo = repo;
        }

        public IList<BusinessObject.Models.Medication> Medications { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Medications = (await _repo.GetMany()).ToList();
        }
    }
}
