﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BusinessObject;
using BusinessObject.Models;
using DataAccess.Repository;

namespace PrescriptionWeb.Pages.Medication
{
    public class DeleteModel : PageModel
    {
        private readonly MedicationRepository _repo;

        public DeleteModel(MedicationRepository repo)
        {
            _repo = repo;
        }

        [BindProperty]
      public BusinessObject.Models.Medication Medication { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medication = await _repo.GetFirst(m => m.MedicationId == id);

            if (medication == null)
            {
                return NotFound();
            }
            else 
            {
                Medication = medication;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var medication = await _repo.GetFirst(m => m.MedicationId == id);

            if (medication != null)
            {
                Medication = medication;
                await _repo.Delete(Medication);
            }

            return RedirectToPage("./Index");
        }
    }
}
