﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BusinessObject.Models
{
    public class Diagnosis
    {
        [Key]
        [Column(TypeName = "varchar(100)")]
        public string DiagnosisId { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string Name { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string Conclusion { get; set; }

        public virtual ICollection<PrescriptionDiagnosis>? PrescriptionDiagnoses { get; set; }
    }
}