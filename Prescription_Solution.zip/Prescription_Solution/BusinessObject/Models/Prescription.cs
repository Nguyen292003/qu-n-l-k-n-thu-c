﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.Models
{
    public class Prescription
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PrescriptionId { get; set;  }
        [Column(TypeName = "nvarchar(200)")]
        public string FullName { get; set; }
        public DateTime BirthDay { get; set; }

        public int Weight { get; set; }
        [Column(TypeName = "nvarchar(20)")]
        public string Gender { get; set; }
        [Column(TypeName = "varchar(20)")]
        public string? HealthInsuranceId { get; set; }
        [Column(TypeName = "varchar(15)")]
        public string Phone { get; set; }
        [Column(TypeName = "varchar(20)")]
        public string? IdentifierId { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string Address { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string FormOfTreatment { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string Note { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string Advice { get; set; }

        public int ReExamDay { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string? ParentName { get; set; }

        public virtual ICollection<PrescriptionMedication>? PrescriptionMedications { get; set; }
        public virtual ICollection<PrescriptionDiagnosis>? PrescriptionDiagnoses { get; set; }


    }
}
