﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.Models
{
    public class PrescriptionMedication
    {
        [ForeignKey(nameof(Prescription))]
        public int PrescriptionId { get; set; }
        [ForeignKey(nameof(Medication))]
        public string MedicationId { get; set; }

        [Column(TypeName = "nvarchar(1000)")]
        public string Instructions { get; set; }

        public virtual Medication Medication { get; set; }

        public virtual Prescription Prescription { get; set; }
    }
}
