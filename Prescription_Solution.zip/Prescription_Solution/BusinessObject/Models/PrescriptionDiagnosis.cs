﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.Models
{
    public class PrescriptionDiagnosis
    {
        [ForeignKey(nameof(Prescription))]
        public int PrescriptionId { get; set; }
        [ForeignKey(nameof(Diagnosis))]
        public string DiagnosisId { get; set; }

        public virtual Diagnosis Diagnosis { get; set; }

        public virtual Prescription Prescription { get; set; }
    }
}
