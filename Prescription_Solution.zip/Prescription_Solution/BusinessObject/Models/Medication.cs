﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BusinessObject.Models
{
    public class Medication
    {
        [Key]
        [Column(TypeName = "varchar(100)")]
        public string MedicationId { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string ActiveIngredient { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string Name { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string Unit { get; set; }

        public int Amount { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string RegistrationNumber { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string Manufacturer { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string Pack { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string Content { get; set; }

        public virtual ICollection<PrescriptionMedication>? PrescriptionMedications { get; set; }
    }
}