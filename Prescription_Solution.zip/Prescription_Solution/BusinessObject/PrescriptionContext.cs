﻿using BusinessObject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject
{
    public class PrescriptionContext : DbContext
    {
        public PrescriptionContext() : base()
        {
        }

        public PrescriptionContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Diagnosis> Diagnoses { get; set; } = null!;

        public DbSet<Medication> Medications { get; set; } = null!;

        public DbSet<Prescription> Prescriptions { get; set; } = null!;

        public DbSet<PrescriptionDiagnosis> PrescriptionDiagnoses { get; set; } = null!;

        public DbSet<PrescriptionMedication> PrescriptionMedications { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            //optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=PrescriptionDB;Integrated Security=True;TrustServerCertificate=True");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<PrescriptionMedication>().HasKey(e => new { e.PrescriptionId, e.MedicationId });
            modelBuilder.Entity<PrescriptionDiagnosis>().HasKey(e => new { e.PrescriptionId, e.DiagnosisId });
        }
    }
}
